package com.example.projectuasmoprog;

import android.content.Context;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class NegaraAdapter extends RecyclerView.Adapter<NegaraAdapter.NegaraViewHolder>{
    private Context context;
    private ArrayList<Negara> negaras;

    public NegaraAdapter(Context mcontext, ArrayList<Negara> daftarnegara){
        context=mcontext;
        negaras=daftarnegara;

    }

    @NonNull
    @Override
    public NegaraViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_negara,parent,false);
        return new NegaraViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull NegaraViewHolder holder, int position) {
        Negara negarabaru = negaras.get(position);
        String gambarbaru = negarabaru.getGambar();
        String deskripsi=negarabaru.getDeskripsi();
        String negara = negarabaru.getNegara();

        holder.adapter_negara.setText(negara);
        holder.adapter_deskripsi.setText(deskripsi);
        Glide
                .with(context)
                .load(gambarbaru)
                .centerCrop()
                .into(holder.adapter_gambar);

    }

    @Override
    public int getItemCount() {
        return negaras.size();
    }

    public class NegaraViewHolder extends RecyclerView.ViewHolder {
        public ImageView adapter_gambar;
        public TextView adapter_negara;
        public TextView adapter_deskripsi;

        public NegaraViewHolder(@NonNull View itemView) {
            super(itemView);
            adapter_negara=itemView.findViewById(R.id.TvNegara);
            adapter_gambar=itemView.findViewById(R.id.GambarNegara);
            adapter_deskripsi=itemView.findViewById(R.id.TvDeskripsi);


        }
    }


}
