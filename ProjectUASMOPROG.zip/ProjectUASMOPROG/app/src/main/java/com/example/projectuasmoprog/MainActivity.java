package com.example.projectuasmoprog;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private NegaraAdapter negaraAdapter;
    private RecyclerView recyclerView;
    private ArrayList<Negara> negaras;
    int jumlahdata;
    private RequestQueue requestQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView=findViewById(R.id.RvList);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        negaras = new ArrayList<>();
        requestQueue= Volley.newRequestQueue(this);
        parseJSON();
    }

    private void parseJSON() {
        String url = "https://api.npoint.io/a503a1e9c9c6c0745fc4";
        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        jumlahdata = response.length();
                        try {
                            for (int i = 0; i < jumlahdata; i++) {
                                JSONObject data = response.getJSONObject(i);
                                String gambarnegara = data.getString("gambar");
                                String namanegara = data.getString("nama");
                                String deskripsinegara = data.getString("kota");
                                negaras.add(new Negara(namanegara, deskripsinegara, gambarnegara));
                            }
                            negaraAdapter = new NegaraAdapter(MainActivity.this, negaras);
                            recyclerView.setAdapter(negaraAdapter);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

            }

    });
        requestQueue.add(request);

    }

}