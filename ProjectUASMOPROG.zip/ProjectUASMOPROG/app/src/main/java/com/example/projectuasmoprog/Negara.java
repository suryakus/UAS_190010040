package com.example.projectuasmoprog;

import android.view.Menu;

public class Negara {
    private String negara;
    private String deskripsi;
    private String gambar;

    public Negara(String datanegara, String datadeskripsi, String datagambar){
        negara = datanegara;
        deskripsi = datadeskripsi;
        gambar = datagambar;
    }

    public String getNegara() {
        return negara;
    }

    public String getDeskripsi() {
        return deskripsi;
    }

    public String getGambar() {
        return gambar;
    }
}
